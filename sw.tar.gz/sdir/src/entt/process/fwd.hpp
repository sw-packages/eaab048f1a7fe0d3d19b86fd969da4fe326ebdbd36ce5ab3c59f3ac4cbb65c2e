#ifndef ENTT_PROCESS_FWD_HPP
#define ENTT_PROCESS_FWD_HPP

namespace entt {

template<typename, typename>
class process;

template<typename>
class scheduler;

} // namespace entt

#endif
